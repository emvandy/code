﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SystemParking
{
    public partial class FormSection : Form
    {
        int numNo = 1;
        int IndexEdit;
        public FormSection()
        {
            InitializeComponent();
        }

        private void FormSection_Load(object sender, EventArgs e)
        {
            dataGrid.Font = new System.Drawing.Font("Segoe Print", 10, FontStyle.Bold);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            dataGrid.Rows.Add(numNo.ToString(), texName.Text, texCapacity.Text, textCost.Text, textDecription.Text);
        }

        private void btnEdite_Click(object sender, EventArgs e)
        {
            DataGridViewRow newdata = dataGrid.Rows[IndexEdit];
            newdata.Cells[1].Value = texName.Text;
            newdata.Cells[2].Value = texCapacity.Text;
            newdata.Cells[3].Value = textCost.Text;
            newdata.Cells[4].Value = textDecription.Text;
        }

        private void btnDalate_Click(object sender, EventArgs e)
        {
            int rowCount = dataGrid.RowCount;
            if(IndexEdit < rowCount)
            {
                dataGrid.Rows.RemoveAt(IndexEdit);
            }
        }
        private void dataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            IndexEdit = e.RowIndex;
        }
    }
}
