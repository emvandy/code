﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SystemParking
{
    public partial class ParkingForm : Form
    {
        Form sForm =  null;
        public ParkingForm()
        {
            InitializeComponent();
        }
        public void openForm(Form childForm)
        {
            if(sForm != null)
            {
                sForm.Close();
            }
            sForm = childForm;
            childForm.TopLevel = false;
            panelForm.Controls.Add(childForm);
            panelForm.BringToFront();
            childForm.Dock = DockStyle.Fill;
            childForm.Show();
            
        }
        private void btnReport_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MainForm.ActiveForm.WindowState = FormWindowState.Normal;
            MainForm.ActiveForm.TopMost = true;
            this.Close();
        }

        private void btnSection_Click(object sender, EventArgs e)
        {
            openForm(new FormSection());
        }

        private void ParkingForm_Load(object sender, EventArgs e)
        {
            this.Size = new System.Drawing.Size(1300, 800);
        }
    }
}
