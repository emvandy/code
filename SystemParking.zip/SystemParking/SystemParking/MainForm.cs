﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SystemParking
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
        public void Login()
        {
            if (texName.Text.ToLower() == "vandy")
            {
                if (textPassword.Text == "123")
                {
                    DialogResult result = MessageBox.Show("Successful!", "info", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        ParkingForm sform = new ParkingForm();
                        sform.Show(); 
                    }
                }
            }
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            if(texName.Text == "Name")
            {
                texName.Text = "";
                texName.ForeColor = Color.Black;
            }
        }

        private void texName_TextChanged(object sender, EventArgs e)
        {

        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            this.ActiveControl = null;
            this.Size = new System.Drawing.Size(450, 700);
        }

        private void texName_Leave(object sender, EventArgs e)
        {
            if(texName.Text == "")
            {
                texName.Text = "Name";
                texName.ForeColor = Color.DarkGray;
            }
        }

        private void texEmail_Enter(object sender, EventArgs e)
        {
            if(texEmail.Text == "Email Address or Phone number")
            {
                texEmail.Text = "";
                texEmail.ForeColor = Color.Black;
            }
        }

        private void texEmail_Leave(object sender, EventArgs e)
        {
            if(texEmail.Text == "")
            {
                texEmail.Text = "Email Address or Phone number";
                texEmail.ForeColor = Color.DarkGray;
            }
        }

        private void textPassword_Enter(object sender, EventArgs e)
        {
            if(textPassword.Text == "Password")
            {
                textPassword.Text = "";
                textPassword.ForeColor = Color.Black;
            }
        }

        private void textPassword_Leave(object sender, EventArgs e)
        {
            if(textPassword.Text == "")
            {
                textPassword.Text = "Password";
                textPassword.ForeColor = Color.DarkGray;
            }
        }

        private void btnAdmin_Click(object sender, EventArgs e)
        {
            Login();
        }

        private void btnUser_Click(object sender, EventArgs e)
        {
            Login();
        }
    }
}
